# Report: PMI_Final | target=gdp_lead
- Rows used: 39
- HAC maxlags used: 3
- OOS training length: 20

## Best OOS models by RMSFE
|   N_oos |   RMSFE |     MAE |      ME | model                   |
|--------:|--------:|--------:|--------:|:------------------------|
|      19 | 12.0316 | 7.27985 | 2.74175 | AR+Covid+Employment0    |
|      19 | 13.0712 | 7.97761 | 3.68453 | Joint_AllComponents     |
|      19 | 13.1828 | 7.47062 | 3.36391 | Baseline_AR+Covid       |
|      19 | 13.2191 | 7.53358 | 3.44231 | AR+Covid+Output0        |
|      19 | 13.2871 | 7.59463 | 3.47857 | AR+Covid+New Orders0    |
|      19 | 13.3472 | 7.59971 | 3.38594 | AR+Covid+Future Output0 |
|      19 | 13.3829 | 7.58142 | 3.39193 | AR+Covid+Output Prices0 |
|      19 | 13.4696 | 7.63593 | 3.45408 | AR+Covid+Input Prices0  |

## Component regressions (ranked by p-value)
| predictor      |     beta_x |     se_x |       t_x |       p_x |       R2 |   Adj_R2 |   N |   rank_p |
|:---------------|-----------:|---------:|----------:|----------:|---------:|---------:|----:|---------:|
| Employment0    | -2.23475   | 1.34998  | -1.65539  | 0.0978452 | 0.358353 | 0.303355 |  39 |        1 |
| Output Prices0 | -0.443292  | 0.440746 | -1.00578  | 0.314523  | 0.219949 | 0.153087 |  39 |        2 |
| Input Prices0  |  0.222335  | 0.247287 |  0.899097 | 0.368601  | 0.213868 | 0.146485 |  39 |        3 |
| Future Output0 |  0.0323466 | 0.1156   |  0.279815 | 0.779619  | 0.207623 | 0.139705 |  39 |        4 |
| Output0        | -0.0426739 | 0.288211 | -0.148065 | 0.882292  | 0.207744 | 0.139837 |  39 |        5 |
| New Orders0    | -0.0278088 | 0.260492 | -0.106755 | 0.914983  | 0.207268 | 0.13932  |  39 |        6 |

## VIF (multicollinearity)
| variable       |       VIF |
|:---------------|----------:|
| New Orders0    | 216.648   |
| Output0        | 204.137   |
| Output Prices0 |   7.03959 |
| Input Prices0  |   4.16801 |
| Future Output0 |   3.19391 |
| Employment0    |   2.07624 |

## Shapley R^2 attribution
| predictor      |   shapley_R2 |
|:---------------|-------------:|
| Employment0    |   0.174818   |
| Input Prices0  |   0.0687492  |
| Output Prices0 |   0.0545694  |
| New Orders0    |   0.0101533  |
| Output0        |   0.00974843 |
| Future Output0 |   0.00642413 |