# Report: PMI_Final | target=real_proxy
- Rows used: 39
- HAC maxlags used: 3
- OOS training length: 20

## Best OOS models by RMSFE
|   N_oos |   RMSFE |     MAE |      ME | model                   |
|--------:|--------:|--------:|--------:|:------------------------|
|      19 | 12.8203 | 7.71139 | 3.25795 | AR+Covid+Employment0    |
|      19 | 12.9176 | 7.53711 | 2.99875 | AR+Covid+Output Prices0 |
|      19 | 13.1927 | 7.5431  | 3.14021 | AR+Covid+Input Prices0  |
|      19 | 13.3691 | 7.61508 | 2.98813 | AR+Covid+Future Output0 |
|      19 | 13.4053 | 7.21993 | 3.52855 | Baseline_AR+Covid       |
|      19 | 13.5707 | 7.50893 | 3.59281 | AR+Covid+New Orders0    |
|      19 | 13.8646 | 7.61132 | 3.70016 | AR+Covid+Output0        |
|      19 | 13.9042 | 8.81282 | 3.48542 | Joint_AllComponents     |

## Component regressions (ranked by p-value)
| predictor      |     beta_x |     se_x |        t_x |       p_x |       R2 |   Adj_R2 |   N |   rank_p |
|:---------------|-----------:|---------:|-----------:|----------:|---------:|---------:|----:|---------:|
| Output Prices0 | -0.715541  | 0.400677 | -1.78583   | 0.0741267 | 0.222908 | 0.1563   |  39 |        1 |
| Employment0    | -2.06048   | 1.3568   | -1.51863   | 0.128856  | 0.310909 | 0.251844 |  39 |        2 |
| Future Output0 | -0.031116  | 0.128109 | -0.242886  | 0.808094  | 0.191888 | 0.122621 |  39 |        3 |
| Input Prices0  |  0.0653324 | 0.303423 |  0.215317  | 0.82952   | 0.191801 | 0.122527 |  39 |        4 |
| Output0        | -0.0130479 | 0.30547  | -0.0427142 | 0.965929  | 0.191315 | 0.121999 |  39 |        5 |
| New Orders0    | -0.0102003 | 0.279641 | -0.0364764 | 0.970902  | 0.191289 | 0.121971 |  39 |        6 |

## VIF (multicollinearity)
| variable       |       VIF |
|:---------------|----------:|
| New Orders0    | 216.648   |
| Output0        | 204.137   |
| Output Prices0 |   7.03959 |
| Input Prices0  |   4.16801 |
| Future Output0 |   3.19391 |
| Employment0    |   2.07624 |

## Shapley R^2 attribution
| predictor      |   shapley_R2 |
|:---------------|-------------:|
| Employment0    |   0.133601   |
| Output Prices0 |   0.0776795  |
| Input Prices0  |   0.0547749  |
| New Orders0    |   0.0121319  |
| Output0        |   0.0112122  |
| Future Output0 |   0.00640917 |