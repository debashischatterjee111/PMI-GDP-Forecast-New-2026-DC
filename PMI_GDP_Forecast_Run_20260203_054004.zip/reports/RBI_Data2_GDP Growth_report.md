# Report: RBI_Data2 | target=GDP Growth
- Rows used: 39
- HAC maxlags used: 3
- OOS training length: 20

## Best OOS models by RMSFE
|   N_oos |   RMSFE |     MAE |      ME | model                               |
|--------:|--------:|--------:|--------:|:------------------------------------|
|      19 | 12.3987 | 7.65093 | 3.65249 | AR+Covid+Employment(0)              |
|      19 | 13.0683 | 8.06623 | 4.53037 | AR+Covid+Manufacturing Index (0)    |
|      19 | 13.1297 | 8.42106 | 4.40728 | Joint_AllComponents                 |
|      19 | 13.2811 | 7.90409 | 4.05343 | AR+Covid+Output Prices(0)           |
|      19 | 13.4247 | 7.92306 | 4.09768 | AR+Covid+Input Prices(0)            |
|      19 | 13.4624 | 7.89468 | 4.16663 | Baseline_AR+Covid                   |
|      19 | 14.0505 | 8.0913  | 4.40152 | AR+Covid+COMPOSITE OUTPUT INDEX( 0) |

## Component regressions (ranked by p-value)
| predictor                  |     beta_x |     se_x |       t_x |      p_x |       R2 |   Adj_R2 |   N |   rank_p |
|:---------------------------|-----------:|---------:|----------:|---------:|---------:|---------:|----:|---------:|
| Employment(0)              | -113.537   | 71.0207  | -1.59865  | 0.109898 | 0.312384 | 0.253446 |  39 |        1 |
| Output Prices(0)           |  -33.3665  | 23.6023  | -1.4137   | 0.157451 | 0.188332 | 0.118761 |  39 |        2 |
| Input Prices(0)            |   22.6423  | 17.2112  |  1.31556  | 0.188323 | 0.190981 | 0.121637 |  39 |        3 |
| Manufacturing Index (0)    |    8.58528 | 17.3924  |  0.493623 | 0.621573 | 0.174882 | 0.104158 |  39 |        4 |
| COMPOSITE OUTPUT INDEX( 0) |    2.92144 |  6.70552 |  0.435677 | 0.663071 | 0.172806 | 0.101904 |  39 |        5 |

## VIF (multicollinearity)
| variable                   |     VIF |
|:---------------------------|--------:|
| Input Prices(0)            | 3.64984 |
| Output Prices(0)           | 3.54152 |
| Manufacturing Index (0)    | 2.20489 |
| Employment(0)              | 2.0034  |
| COMPOSITE OUTPUT INDEX( 0) | 1.26078 |

## Shapley R^2 attribution
| predictor                  |   shapley_R2 |
|:---------------------------|-------------:|
| Employment(0)              |    0.184217  |
| Input Prices(0)            |    0.0891583 |
| Output Prices(0)           |    0.0642033 |
| Manufacturing Index (0)    |    0.0342912 |
| COMPOSITE OUTPUT INDEX( 0) |    0.0297247 |